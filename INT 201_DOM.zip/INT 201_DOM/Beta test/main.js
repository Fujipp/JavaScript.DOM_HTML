let msg = document.getElementById('message-1');
msg.innerHTML = 'ก็มาดิคร้าบบบ';

let mssg = document.getElementById('message-2');
mssg.inn