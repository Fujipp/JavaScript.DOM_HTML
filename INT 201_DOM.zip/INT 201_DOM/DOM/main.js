const message_h1 = document.getElementsByTagName('h1')[0]
const message_p = document.getElementsByTagName('p')[0]
const message_ul = document.getElementsByTagName('ul')[0]

