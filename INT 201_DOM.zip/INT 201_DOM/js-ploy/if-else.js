/*
    Compare operator
        - == / ===
        - != / !==
        - >
        - >=
        - <
        - <=
*/

let x = 20;

if(x > 20) { // (condition) true
    console.log("my x > 20!!!");
} 
else if(x === 20) {
    console.log("my x = 20!!!");
}
else { // false
    console.log("my x < 20!!!");
}
